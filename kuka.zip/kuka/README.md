# Kuka

Application de streaming musical (PWA) inspirée de Spotify. Installable sur téléphone, fonctionne hors ligne.

## Lancer en local
Ouvre `index.html` dans un navigateur, ou lance `python3 -m http.server` puis va sur http://localhost:8000.

## Déploiement
Chaque push sur `main` publie le site via GitHub Pages (voir `.github/workflows/pages.yml`).
